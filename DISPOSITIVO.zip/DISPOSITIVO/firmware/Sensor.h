#include "Particle.h"

#define Addr_a 0x53
#define Addr_g 0x69

class Sensor{
public:
  Sensor();
  int get_xAccl(){return xAccl;};
  int get_yAccl(){return yAccl;};
  int get_zAccl(){return zAccl;};

  int get_xGyro(){return xGyro;};
  int get_yGyro(){return yGyro;};
  int get_zGyro(){return zGyro;};


  unsigned int *get_data_a(){return data_a;};
  unsigned int *get_data_g(){return data_g;};


private:
  int xAccl;
  int yAccl;
  int zAccl;
  unsigned int data_a[6];

  int xGyro;
  int yGyro;
  int zGyro;
  unsigned int data_g[6];


};

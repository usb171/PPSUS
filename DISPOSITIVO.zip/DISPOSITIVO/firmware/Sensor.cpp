#include "Sensor.h"

Sensor::Sensor(){
   // Initialise I2C communication as MASTER
   Wire.begin();
   // Start I2C transmission
   Wire.beginTransmission(Addr_a);
   // Select bandwidth rate register
   Wire.write(0x2C);
   // Select output data rate = 100 Hz
   Wire.write(0x0A);
   // Stop I2C Transmission
   Wire.endTransmission();

   // Start I2C transmission
   Wire.beginTransmission(Addr_a);
   // Select power control register
   Wire.write(0x2D);
   // Select auto sleep disable
   Wire.write(0x08);
   // Stop I2C transmission
   Wire.endTransmission();

   // Start I2C transmission
   Wire.beginTransmission(Addr_a);
   // Select data format register
   Wire.write(0x31);
   // Select full resolution, +/-2g
   Wire.write(0x08);
   // End I2C transmission
   Wire.endTransmission();


   // CTRL_REG2
   Wire.beginTransmission(Addr_g);
   Wire.write(0x21);
   Wire.write(0x00);
   Wire.endTransmission();

   //CTRL_REG3
   Wire.beginTransmission(Addr_g);
   Wire.write(0x22);
   Wire.write(0x00);
   Wire.endTransmission();

   // CTRL_REG4
   Wire.beginTransmission(Addr_g);
   Wire.write(0x23);
   Wire.write(0x00);
   Wire.endTransmission();

   // CTRL_REG6
   Wire.beginTransmission(Addr_g);
   Wire.write(0x25);
   Wire.write(0x00);
   Wire.endTransmission();

   // CTRL_REG5
   Wire.beginTransmission(Addr_g);
   Wire.write(0x24);
   Wire.write(0x00);
   Wire.endTransmission();

   //CTRL_REG1
   Wire.beginTransmission(Addr_g);
   Wire.write(0x20);
   Wire.write(0x0F);
   Wire.endTransmission();
}

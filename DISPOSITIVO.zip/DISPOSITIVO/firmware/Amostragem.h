#include "Particle.h"
#include "TinyGPS_SparkCore/TinyGPS.h"
#include "SdFat/SdFat.h"


String ID = "D02"; // ID do dispositivo
SdBaseFile binFile;
const int8_t ERROR_LED_PIN = D7;
const uint8_t BUFFER_BLOCK_COUNT = 8; //Assume ARM. Use total of nine 512 byte buffers.
const uint32_t FILE_BLOCK_COUNT = 2400;
const uint32_t LOG_INTERVAL_USEC = 8325; // Em microseconds

SdFat sd;
const uint8_t SD_CS_PIN = SS;
#define TMP_FILE_NAME "tmp_log.bin"

const uint8_t VAR_DIM = 6;
const bool useSharedSpi = false;
uint32_t const ERASE_SIZE = 262144L;

struct data_t {
  unsigned long time;
  unsigned short eixos[VAR_DIM];
  float latitude;
  float longitude;
};

const uint16_t DATA_DIM = (512 - 4)/sizeof(data_t);
const uint16_t FILL_DIM = 512 - 4 - DATA_DIM*sizeof(data_t);
const uint8_t QUEUE_DIM = BUFFER_BLOCK_COUNT + 2;

struct block_t {
  uint16_t count;
  uint16_t overrun;
  data_t data[DATA_DIM];
  uint8_t fill[FILL_DIM];
};

block_t* emptyQueue[QUEUE_DIM];
uint8_t emptyHead;
uint8_t emptyTail;

block_t* fullQueue[QUEUE_DIM];
uint8_t fullHead;
uint8_t fullTail;


SYSTEM_MODE(MANUAL); // Conexão manual com a nuvem de partículas
STARTUP (WiFi.selectAntenna(ANT_EXTERNAL)) //Conexão com antena externa
STARTUP(RGB.control(true))
STARTUP(RGB.color(0, 0, 0))
STARTUP(pinMode(ERROR_LED_PIN, OUTPUT))


/////////////////////////////////// Sensor /////////////////////////////////////
#define Addr_a 0x53
#define Addr_g 0x69

uint8_t xAccl;
uint8_t yAccl;
uint8_t zAccl;

uint8_t xGyro;
uint8_t yGyro;
uint8_t zGyro;

uint8_t data_a[6];
uint8_t data_g[6];

////////////////////////////////////////////////////////////////////////////////


TinyGPS gps;
float lat, lon;
unsigned long age;

void onSerialData();
Timer _timer = Timer(1, onSerialData);


void initGPS();
void initRede(); // Inicia as configurações de rede
void initSensor(); // Inicia as configurações dos sensores
void initAmostragem(); // Inicia as configurações para logs no cartão SD

void binaryToCsv();
void logData(); // Faz a salva os dados no cartão SD
void dumpData(); // Imprime os dados na serial
void fatalBlink(); // Indica erro por LED
void error(const char* msg); // Propaga erros
void printHeader(Print* pr); // Imprime o cabeçalho dos dados
inline void acquireData(data_t* data); // Aquisita os dados
void printData(Print* pr, data_t* data); // Imprime os dados
inline uint8_t queueNext(uint8_t ht); // Retorna a posição do próximo elemento

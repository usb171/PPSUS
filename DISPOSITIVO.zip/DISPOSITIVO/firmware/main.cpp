#include "Particle.h"
#include "Mqtt/Mqtt.h"
#include "SdFat/SdFat.h"
#include "TinyGPS_SparkCore/TinyGPS.h"


#define ID_DEVICE "D03"
#define TMP_FILE_NAME "tmp_log.bin"

SYSTEM_MODE(MANUAL); // Conexão manual com a nuvem de partículas
STARTUP(RGB.control(true)) // Habilita o controle dos LEDs RGB
STARTUP(RGB.color(0, 0, 0)) // Apagas os LEDs RGB
STARTUP(pinMode(D7, OUTPUT)) // Define o Led D7 como saída digital
STARTUP(pinMode(D3, OUTPUT)) // Define o Buzzer D3 como saída digital
STARTUP (WiFi.selectAntenna(ANT_EXTERNAL)) //Conexão com antena externa

// Tom de inicialização //////////
STARTUP(tone(D3, 1000, 250))
STARTUP(delay(100))
STARTUP(tone(D3, 2000, 250))
STARTUP(delay(100))
STARTUP(tone(D3, 4000, 250))
////////////////////////////////////

String ID = "D03"; // ID do dispositivo

const int8_t ERROR_LED_PIN = D7; // Pino LED D7
const uint8_t BUFFER_BLOCK_COUNT = 8; // Uso total de nove blocos de 512 byte buffers.
const uint32_t FILE_BLOCK_COUNT = 2400; // Total de blocos alocados do cartão SD a cada coleta
const uint32_t LOG_INTERVAL_USEC = 8000; // delay em microsegundos entre cada amostra

SdFat sd;
SdBaseFile binFile;

const uint8_t SD_CS_PIN = SS;
const uint8_t VAR_DIM = 6;
const bool useSharedSpi = false;
uint32_t const ERASE_SIZE = 262144L;

struct data_t {
  unsigned long time;
  unsigned short eixos[VAR_DIM];
  float latitude;
  float longitude;
};

const uint16_t DATA_DIM = (512 - 4)/sizeof(data_t);
const uint16_t FILL_DIM = 512 - 4 - DATA_DIM*sizeof(data_t);
const uint8_t QUEUE_DIM = BUFFER_BLOCK_COUNT + 2;

struct block_t {
  uint16_t count;
  uint16_t overrun;
  data_t data[DATA_DIM];
  uint8_t fill[FILL_DIM];
};

block_t* emptyQueue[QUEUE_DIM];
uint8_t emptyHead;
uint8_t emptyTail;

block_t* fullQueue[QUEUE_DIM];
uint8_t fullHead;
uint8_t fullTail;




/////////////////////////////////// Sensor /////////////////////////////////////
#define Addr_a 0x53
#define Addr_g 0x69

uint8_t xAccl;
uint8_t yAccl;
uint8_t zAccl;

uint8_t xGyro;
uint8_t yGyro;
uint8_t zGyro;

uint8_t data_a[6];
uint8_t data_g[6];

////////////////////////////////////////////////////////////////////////////////


TinyGPS gps;
float lat, lon;
unsigned long age;

bool FLAG_REC = false;

MQTT *client;
byte server[] = {192,168,43,34};
char *SSID = "FAPEPI";
char *PASSWORD = "pesquisa";
char line[200];


void initGPS(); // Inicia configurações GPS
bool initRede(); // Inicia as configurações de rede
void initSensor(); // Inicia as configurações dos sensores
void onSerialData(); // Refresh GPS

void logData(); // Faz a salva os dados no cartão SD
void dumpDataType(int code); // Imprime os dados na serial
void fatalBlink(); // Indica erro por LED
void binaryToCsv();
void error(const char* msg); // Propaga erros
void printHeader(Print* pr); // Imprime o cabeçalho dos dados
inline void acquireData(data_t* data); // Aquisita os dados
void printData(Print* pr, data_t* data); // Imprime os dados

void printSelectData(Print* pr, data_t* data, int code); // Imprime os dados selecionados

inline uint8_t queueNext(uint8_t ht); // Retorna a posição do próximo elemento
void switch_mqtt(char* topic, byte* payload, unsigned int length);



Timer _timer = Timer(1, onSerialData);


void setup(void) {

  WiFi.disconnect();
  WiFi.on();
  WiFi.setCredentials(SSID, PASSWORD);


  Serial.begin(9600);
  while (!Serial) SysCall::yield();
  if (sizeof(block_t) != 512) error("Tamanho de bloco inválido");
  if (!sd.begin(SD_CS_PIN, SPI_FULL_SPEED)){
    sd.initErrorPrint();
    fatalBlink();
  }
  delay(2000);

  if(!initRede()) System.reset();
  initSensor();
  initGPS();

}
//------------------------------------------------------------------------------
void loop(void) {
  client->loop();
}

void switch_mqtt(char* topic, byte* payload, unsigned int length){
    char p[length + 1];
    memcpy(p, payload, length);
    p[length] = NULL;
    String message(p);

    String code = message.substring(0,2);
    String user = message.substring(2,5);
    String msg  = message.substring(5);

    Serial.print("Code: ");
    Serial.println(code);
    Serial.print("User: ");
    Serial.println(user);
    Serial.print("Msg: ");
    Serial.println(msg);


    if (code.equals("L1")){
        RGB.color(255, 0, 0);
        client->publish("device/"  + user + "/code", msg);
        tone(D3, 4000, 100);
    }
    else if (code.equals("L2")){
        RGB.color(0, 255, 0);
        client->publish("device/"  + user + "/code", msg);
        tone(D3, 4000, 100);
    }
    else if (code.equals("L3")){
        RGB.color(0, 0, 255);
        client->publish("device/"  + user + "/code", msg);
        tone(D3, 4000, 100);
    }
    else if (code.equals("C1")){ //RSSI
        tone(D3, 4000, 100);
        client->publish("device/"  + user + "/code", String(WiFi.RSSI()));
        tone(D3, 4000, 100);
    }
    else if (code.equals("C2")){
        tone(D3,2000,100);
        tone(D3,2000,100);
        delay(900);
        tone(D3,2000,100);
        delay(900);
        tone(D3,2000,1000);


        client->publish("device/"  + user + "/code", msg + "C2T");
        logData();
        client->publish("device/"  + user + "/code", msg + "C2T");
        tone(D3, 4000, 100);
    }
    else if (code.equals("C3")){
        FLAG_REC = true;
        tone(D3, 4000, 100);
        client->publish("device/"  + user + "/code", msg);
        tone(D3, 4000, 100);
        tone(D3,500,2000);
        dumpDataType(msg.toInt());
        client->publish("device/"  + user + "/code", msg + "C3T");
        tone(D3, 4000, 100);
    }
    else if (code.equals("C4")){
        client->publish("device/"  + user + "/code", msg);
        tone(D3, 4000, 100);
        if(sd.remove("amostras.csv")) client->publish("device/"  + user + "/code", msg + "C4T");
        tone(D3, 4000, 100);
    }
    else if (code.equals("C5")){
        tone(D3, 4000, 100);
        client->publish("device/"  + user + "/code", msg + "C5T");
        tone(D3, 4000, 100);
        FLAG_REC = true;
    }
    else if (code.equals("C6")){
        tone(D3, 4000, 100);
        client->publish("device/"  + user + "/code", msg + "C6T");
        binaryToCsv();
        tone(D3, 4000, 100);
    }
    else if (code.equals("RE")){ // Reseta o dispositivo
      System.reset();
    }
    else{
        RGB.color(255, 255, 255);
        tone(D3, 1000, 500);
    }
}

void onSerialData(){
  while (Serial1.available()){
    gps.encode(Serial1.read());
  }
}

void initGPS(){
  Serial1.begin(9600);
  _timer.start();
}

bool initRede(){

  WiFi.on();
  delay(2000);
  while (!WiFi.ready()) WiFi.connect();
  delay(2000);


	client = new MQTT(server, 1883, switch_mqtt, 512); client->connect(ID);

    if (client->isConnected()) {
        client->publish("device/", "Device: " + ID);
        client->subscribe("device/" + ID + "/code");
        for(int i = 0; i < 5; i++){ tone(D3,5000,50); delay(100);}
        return true;
    }else{
    	return false;
    }
}

void initSensor(){
  //Inicia a comunicação I2C Master
  Wire.begin();
  // Inicia uma Transmissão I2C com com o Registrador do Acelerometro
  Wire.beginTransmission(Addr_a);
  // Seleciona o Registrador de Largura de Banda
  Wire.write(0x2C);
  // Seta o data rate de saída em 400 Hz
  Wire.write(0x0C);
  // Finaliza a transmissão I2C
  Wire.endTransmission();

  // Inicia uma Transmissão I2C com com o Registrador do Acelerometro
  Wire.beginTransmission(Addr_a);
  // Seleciona o registrador de controle de energia
  Wire.write(0x2D);
  // Coloca em mensuramento
  Wire.write(0x08);
  // Finaliza a transmissão I2C
  Wire.endTransmission();

  // Inicia uma Transmissão I2C com com o Registrador do Acelerometro
  Wire.beginTransmission(Addr_a);
  // Seleciona o registrador de formato de dados
  Wire.write(0x31);
  // Seta full resulution
  Wire.write(0x08);
  // Finaliza a transmissão I2C
  Wire.endTransmission();


  // CTRL_REG2
  Wire.beginTransmission(Addr_g);
  Wire.write(0x21);
  Wire.write(0x00);
  Wire.endTransmission();

  //CTRL_REG3
  Wire.beginTransmission(Addr_g);
  Wire.write(0x22);
  Wire.write(0x00);
  Wire.endTransmission();

  // CTRL_REG4
  Wire.beginTransmission(Addr_g);
  Wire.write(0x23);
  Wire.write(0x00);
  Wire.endTransmission();

  // CTRL_REG6
  Wire.beginTransmission(Addr_g);
  Wire.write(0x25);
  Wire.write(0x00);
  Wire.endTransmission();

  // CTRL_REG5
  Wire.beginTransmission(Addr_g);
  Wire.write(0x24);
  Wire.write(0x00);
  Wire.endTransmission();

  //CTRL_REG1
  Wire.beginTransmission(Addr_g);
  Wire.write(0x20);
  Wire.write(0x0F);
  Wire.endTransmission();
}

void acquireData(data_t* data){
  data->time = micros();

  for(int interador = 0; interador < 6; interador++){
    // Start I2C transmission
    Wire.beginTransmission(Addr_a);
    // Select data register
    Wire.write((50+interador));
    // Stop I2C transmission
    Wire.endTransmission();
    // Request 1 byte of data from the device
    Wire.requestFrom(Addr_a,1);
    // Read 6 bytes of data
    // xAccl lsb, xAccl msb, yAccl lsb, yAccl msb, zAccl lsb, zAccl msb
    if(Wire.available()==1) data_a[interador] = Wire.read();
  }

  for(int interador = 0; interador < 6; interador++){
    // Start I2C Transmission
    Wire.beginTransmission(Addr_g);
    // Select data register
    Wire.write((40 + interador));
    // Stop I2C transmission
    Wire.endTransmission();
    // Request 1 byte of data
    Wire.requestFrom(Addr_g, 1);
    // Read 6 bytes of data
    // xGyro lsb, xGyro msb, yGyro lsb, yGyro msb, zGyro lsb, zGyro msb
    //while(!Wire.available());
    if(Wire.available() == 1) data_g[interador] = Wire.read();
  }

  // Convert the data to 10-bits
  xAccl = (((data_a[1] & 0x03) * 256) + data_a[0]);
  if(xAccl > 511) xAccl -= 1024;

  yAccl = (((data_a[3] & 0x03) * 256) + data_a[2]);
  if(yAccl > 511) yAccl -= 1024;

  zAccl = (((data_a[5] & 0x03) * 256) + data_a[4]);
  if(zAccl > 511) zAccl -= 1024;

   // Convert the data
  xGyro = ((data_g[1] * 256) + data_g[0]);
  if (xGyro > 32767) xGyro -= 65536;

  yGyro = ((data_g[3] * 256) + data_g[2]);
  if (yGyro > 32767) yGyro -= 65536;

  zGyro = ((data_g[5] * 256) + data_g[4]);
  if (zGyro > 32767) zGyro -= 65536;

  data->eixos[0] = xAccl;
  data->eixos[1] = yAccl;
  data->eixos[2] = zAccl;
  data->eixos[3] = xGyro;
  data->eixos[4] = yGyro;
  data->eixos[5] = zGyro;

  gps.f_get_position(&lat, &lon, &age);
  data->latitude = lat;
  data->longitude = lon;

  client->loop();
}

void printSelectData(Print* pr, data_t* data, int code){

  switch(code){
    case 0:
      pr->print("Acc X: ");
      pr->println(data->eixos[0]);
      break;
    case 1:
      pr->print("Acc Y: ");
      pr->println(data->eixos[1]);
      break;
    case 2:
      pr->print("Acc Z: ");
      pr->println(data->eixos[2]);
      break;
    case 3:
      pr->print("Gir X: ");
      pr->println(data->eixos[3]);
      break;
    case 4:
      pr->print("Gir Y: ");
      pr->println(data->eixos[4]);
      break;
    case 5:
      pr->print("Gir Z: ");
      pr->println(data->eixos[5]);
      break;
    case 6:
      pr->print("GPS: ");
      pr->print(data->latitude, 8);
      pr->write(',');
      pr->println(data->longitude, 8);
      break;
    case 7:
      pr->print("Time: ");
      pr->println(data->time);
      break;
    default:
      Serial.println("Íten inválido");
  }
  delay(1);
  client->loop();


}

void printData(Print* pr, data_t* data) {
  pr->print(data->time);
  for (int i = 0; i < VAR_DIM; i++) {
    pr->write(',');
    pr->print(data->eixos[i]);
  }
  pr->write(',');
  pr->print(data->latitude, 8);
  pr->write(',');
  pr->print(data->longitude, 8);
  pr->println();
  client->loop();
}

void printHeader(Print* pr) {
  pr->println(F("time,xA,yA,zA,xG,yG,zG"));
}

inline uint8_t queueNext(uint8_t ht) {
  return ht < (QUEUE_DIM - 1) ? ht + 1 : 0;
}
//==============================================================================
void fatalBlink() {
  while (true) {
    if (ERROR_LED_PIN >= 0) {
      digitalWrite(ERROR_LED_PIN, HIGH);
      delay(200);
      digitalWrite(ERROR_LED_PIN, LOW);
      delay(200);
    }
  }
}
//------------------------------------------------------------------------------
void error(const char* msg) {
  sd.errorPrint(msg);
  fatalBlink();
}

// dump data file to Serial
void dumpDataType(int code) {

  block_t block;
  if (!binFile.isOpen()) {
    Serial.println();
    Serial.println(F("No current binary file"));
    return;
  }
  binFile.rewind();
  Serial.println();
  delay(1000);
  printHeader(&Serial);
  while (!Serial.available() && binFile.read(&block , 512) == 512) {
    if (block.count == 0) {
      break;
    }
    if (block.overrun) {
      Serial.print(F("OVERRUN,"));
      Serial.println(block.overrun);
    }
    for (uint16_t i = 0; i < block.count; i++) {
      //printData(&Serial, &block.data[i]);
      printSelectData(&Serial, &block.data[i], code);
    }
  }
  Serial.println(F("Ok"));
}
//------------------------------------------------------------------------------

void logData() {

  uint32_t bgnBlock, endBlock;

  block_t block[BUFFER_BLOCK_COUNT];
  block_t* curBlock = 0;
  Serial.println();


  if (sd.exists(TMP_FILE_NAME)) {
    Serial.println(F("Deletando arquivo temporário"));
    if (!sd.remove(TMP_FILE_NAME)) {
      error("Não foi possível deletar o arquivo temporário");
    }
  }

  binFile.close();
  if (!binFile.createContiguous(sd.vwd(),
                                TMP_FILE_NAME, 512 * FILE_BLOCK_COUNT)) {
    error("Falha ao alocar blocos");
  }

  if (!binFile.contiguousRange(&bgnBlock, &endBlock)) {
    error("Faixa de endereçamento falhou");
  }

  uint8_t* cache = (uint8_t*)sd.vol()->cacheClear();
  if (cache == 0) {
    error("Limpeza de cache falhou");
  }

  Serial.println("Escrevendo ... ");

  uint32_t bgnErase = bgnBlock;
  uint32_t endErase;
  while (bgnErase < endBlock) {
    endErase = bgnErase + ERASE_SIZE;
    if (endErase > endBlock) {
      endErase = endBlock;
    }
    if (!sd.card()->erase(bgnErase, endErase)) {
      error("Apagar falhou");
    }
    bgnErase = endErase + 1;
  }

  if (!sd.card()->writeStart(bgnBlock, FILE_BLOCK_COUNT)) {
    error("Escrita inicial falhou");
  }

  if (useSharedSpi) {
    sd.card()->chipSelectHigh();
  }

  emptyHead = emptyTail = 0;
  fullHead = fullTail = 0;


  emptyQueue[emptyHead] = (block_t*)cache;
  emptyHead = queueNext(emptyHead);


  for (uint8_t i = 0; i < BUFFER_BLOCK_COUNT; i++) {
    emptyQueue[emptyHead] = &block[i];
    emptyHead = queueNext(emptyHead);
  }


  Serial.flush();
  delay(10);
  uint32_t bn = 0;
  uint32_t t0 = millis();
  uint32_t t1 = t0;
  uint32_t overrun = 0;
  uint32_t overrunTotal = 0;
  uint32_t count = 0;
  uint32_t maxDelta = 0;
  uint32_t minDelta = 99999;
  uint32_t maxLatency = 0;
  uint32_t logTime = micros()/LOG_INTERVAL_USEC + 1;
  logTime *= LOG_INTERVAL_USEC;
  FLAG_REC = false;
  while (1) {

    logTime += LOG_INTERVAL_USEC;

    if (FLAG_REC) {
      if (curBlock != 0) {
        fullQueue[fullHead] = curBlock;
        fullHead = queueNext(fullHead);
        curBlock = 0;
      }
    } else {
      if (curBlock == 0 && emptyTail != emptyHead) {
        curBlock = emptyQueue[emptyTail];
        emptyTail = queueNext(emptyTail);
        curBlock->count = 0;
        curBlock->overrun = overrun;
        overrun = 0;
      }
      int32_t usec = logTime - micros();

      delayMicroseconds(usec);
      uint32_t delta = micros() - logTime;
      if (delta > maxDelta) maxDelta = delta;
      if (delta < minDelta) minDelta = delta;

      if (curBlock == 0) {
        overrun++;
      } else {
        acquireData(&curBlock->data[curBlock->count++]);
        if (curBlock->count == DATA_DIM) {
          fullQueue[fullHead] = curBlock;
          fullHead = queueNext(fullHead);
          curBlock = 0;
        }
      }
    }
    if (fullHead == fullTail) {
      if (FLAG_REC) {
        break;
      }
    } else if (!sd.card()->isBusy()) {

      block_t* pBlock = fullQueue[fullTail];
      fullTail = queueNext(fullTail);
      uint32_t usec = micros();
      if (!sd.card()->writeData((uint8_t*)pBlock)) {
        error("Escrita de dados falhou!");
      }
      usec = micros() - usec;
      t1 = millis();
      if (usec > maxLatency) {
        maxLatency = usec;
      }
      count += pBlock->count;


      if (pBlock->overrun) {
        overrunTotal += pBlock->overrun;
        if (ERROR_LED_PIN >= 0) {
          digitalWrite(ERROR_LED_PIN, HIGH);
        }
      }

      emptyQueue[emptyHead] = pBlock;
      emptyHead = queueNext(emptyHead);
      bn++;
      if (bn == FILE_BLOCK_COUNT) {
        break;
      }
    }
  }
  if (!sd.card()->writeStop()) {
    error("Parada da escrita falhou");
  }
  // Truncate file if recording stopped early.
  if (bn != FILE_BLOCK_COUNT) {
    Serial.println(F("Truncando arquivo"));
    if (!binFile.truncate(512L * bn)) {
      error("Não foi possível truncar arquivo");
    }
  }

  Serial.print(F("Max block write usec: "));
  Serial.println(maxLatency);
  Serial.print(F("Record time sec: "));
  Serial.println(0.001*(t1 - t0), 3);
  Serial.print(minDelta);
  Serial.print(F(" <= jitter microseconds <= "));
  Serial.println(maxDelta);
  Serial.print(F("Sample count: "));
  Serial.println(count);
  Serial.print(F("Samples/sec: "));
  Serial.println((1000.0)*count/(t1-t0));
  Serial.print(F("Overruns: "));
  Serial.println(overrunTotal);
  Serial.print(F("OK"));
}

void binaryToCsv() {
  uint8_t lastPct = 0;
  block_t block;
  uint32_t t0 = millis();
  uint32_t syncCluster = 0;
  SdFile csvFile;

  if (!binFile.isOpen()) {
    Serial.println();
    Serial.println(F("Arquivo binário não encontrado"));
    return;
  }
  binFile.rewind();

  if (!csvFile.open("log.csv", O_WRITE | O_CREAT | O_TRUNC)) {
    error("Falha ao abrir arquivo .csv");
  }
  Serial.println();
  Serial.print(F("Escrevendo ... "));
  printHeader(&csvFile);
  uint32_t tPct = millis();
  while (!Serial.available() && binFile.read(&block, 512) == 512) {
    uint16_t i;
    if (block.count == 0) {
      break;
    }
    if (block.overrun) {
      csvFile.print(F("OVERRUN,"));
      csvFile.println(block.overrun);
    }
    for (i = 0; i < block.count; i++) {
      printData(&csvFile, &block.data[i]);
    }
    if (csvFile.curCluster() != syncCluster) {
      csvFile.sync();
      syncCluster = csvFile.curCluster();
    }
    if ((millis() - tPct) > 1000) {
      uint8_t pct = binFile.curPosition()/(binFile.fileSize()/100);
      if (pct != lastPct) {
        tPct = millis();
        lastPct = pct;
        Serial.print(pct, DEC);
        Serial.println('%');
      }
    }
    if (Serial.available()) {
      break;
    }
  }
  csvFile.close();
  Serial.print(F("OK: "));
  Serial.print(0.001*(millis() - t0));
  Serial.println(F(" Segundos"));
}
//------------------------------------------------------------------------------
